<html>
<body>

Welcome <?php echo $_POST["name"]; ?>!<br>
Your guess is: <?php echo $_POST["guess"]; ?>
<?php
$s=$_POST["guess"];
$x=str_replace("=","8",$s);
$mysqli = new mysqli('127.0.0.1', 'root', 'root', 'mainland');
$sql = "SELECT * FROM files WHERE C2='$p'";
$result = $mysqli->query($sql);
while ($res = $result->fetch_assoc()) {
	
	echo "<br>";
	echo "file:".$res['C1'].", name:".$res['C2'].", type:".$res['C3'];
}
sleep(4);
if($p=="the_end"){header('Location: a.txt');}
else{echo "<br>Try again. You'll get there!";}
?>
<br>
<button onClick="window.location.href='index.html'">go back</button>
</body>
</html> 
