
run the challenge.sh like this:
sudo sh challenge.sh

then, open stage1.txt and start the challenge

