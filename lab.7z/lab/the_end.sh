cowsay -f ghostbusters "This is the end. Well done!"

